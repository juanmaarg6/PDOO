/**
 * @file SpecificDamage.java
 * @author Juan Manuel Rodríguez Gómez
 */
package deepspace;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @brief Representa el daño producido a una estación espacial por una nave 
 *        enemiga cuando se pierde un combate. Cada instancia indicará la 
 *        pérdida de una cantidad de potenciadores de escudo y una cantidad
 *        de armas.
 *        Es una clase Hija de Damage.
 *        Además de heredar el atributo de potenciadores de escudo a perder, 
 *        se implementa la cantidad de armas a perder con un array formado por
 *        los tipos de arma
 */
public class SpecificDamage extends Damage {
    
    // Atributo de instancia
    private ArrayList<WeaponType> weapons;
    
    /**
     * @brief Constructor con parámetros
     * @param wl Array de tipos de armas concretas a eliminar
     * @param s Número de potenciadores de escudos a eliminar
     */
    SpecificDamage(ArrayList<WeaponType> wl, int s) {
        super(s);
        weapons = new ArrayList<>(wl);
    }
    
    /**
     * @brief Constructor de copia
     * @param sd Otra instancia de la clase SpecificDamage
     */
    SpecificDamage(SpecificDamage sd) {
        super(sd);
        for(WeaponType w : sd.weapons)
            weapons.add(w);
    }
    
    /**
     * @brief Devuelve una copia del objeto SpecificDamage
     * @return Copia del objeto SpecificDamage
     */
    @Override
    SpecificDamage copy() {
        return new SpecificDamage(weapons, nShields);
    }
    
    /**
     * @brief Consultor de la colección de armas concretas a eliminar
     * @return ArrayList weapons
     */
    public ArrayList<WeaponType> getWeapons() {
        return weapons;
    }
    
    /**
     * @brief Construye una nueva instancia SpecificDamageToUI a partir de la 
     *        propia instancia que recibe el mensaje y lo devuelve.
     *        Estos objetos constituyen una capa que permite conectar el 
     *        modelo con la interfaz de usuario (SpecificDamage) manteniendo 
     *        cierto nivel de aislamiento entre ambos niveles
     * @return Instancia de la clase SpecificDamageToUI
     */
    @Override
    public SpecificDamageToUI getUIversion() {
        return new SpecificDamageToUI(this);
    }
    
    /**
     * @brief Devuelve una versión ajustada del objeto a las colecciones de 
     *        armas y potenciadores de escudos suministradas como parámetro.
     *        Partiendo del daño representado por el objeto que recibe este 
     *        mensaje, se devuelve una copia del mismo pero reducida si es 
     *        necesario para que no implique perder armas o potenciadores de 
     *        escudos que no están en las colecciones de los parámetros
     * @param w Colección de armas disponibles
     * @param s Colección de potenciadores de escudo disponibles
     * @return SpecificDamage ajustado
     */
    @Override
    public SpecificDamage adjust(ArrayList<Weapon> w, ArrayList<ShieldBooster> s) {
        
        // Mínimo entre el número de potenciadores de escudo disponibles y el 
        // número de potenciadores de escudo a eliminar
        int minNShields = Math.min(nShields, s.size());
        
        // Ajuste de la colección de armas concretas a eliminar
        ArrayList<WeaponType> typesCopy = new ArrayList<>();
        ArrayList<Weapon> weaponsCopy = new ArrayList<>();
        ArrayList<WeaponType> adjustTypes = new ArrayList<>();

        // Copia del conjunto de armas concretas a eliminar
        for(int i = 0; i < weapons.size(); i++)
            typesCopy.add( weapons.get(i) );

        // Copia del conjunto de armas disponibles
        for(int i=0; i<w.size(); i++)
            weaponsCopy.add( w.get(i) );

        // Iterador para realizar el ajuste
        Iterator<WeaponType> it = typesCopy.iterator();
        int index;

        // Recorremos todo el vector typesCopy elemento a elemento
        // usando el iterador
        while(it.hasNext()) {
            
            // Seleccionamos el tipo de arma concreta a eliminar
            WeaponType type = it.next();

            // Comprobamos si el tipo de arma concreta a eliminar está
            // en weaponsCopy, es decir, en la copia del conjunto de 
            // armas disponibles
            index = arrayContainsType(weaponsCopy,type);
           
            // En el caso de que el tipo de arma concreta a eliminar está
            // en weaponsCopy, se elimina de weaponsCopy y se añade
            // a adjustTypes
            if(index != -1) {
               weaponsCopy.remove(index);
               adjustTypes.add(type);
            }
           
            it.remove();
        }
        
        // Devolvemos el SpecificDamage ajustado con el número de 
        // potenciadores de escudo y la colección de armas concretas
        // a eliminar
        return new SpecificDamage(adjustTypes, minNShields);
    }
    
    /**
     * @brief Si la instancia dispone de una lista de tipos concretos de armas, 
     *        intenta eliminar el tipo del arma pasada como parámetro de la 
     *        lista de tipos de armas concretas
     * @param w Arma cuyo tipo se va a eliminar de la lista de tipos concretos
     *          de armas disponibles, siempre que sea posible
     */
    @Override
    public void discardWeapon(Weapon w) {
        
        int i = weapons.indexOf( w.getType() );
            
        if(i >= 0)
            weapons.remove(i);  
    }
    
    /**
     * @brief Devuelve True si el daño representado no tiene ningún efecto.
     *        Esto quiere decir que no implica la pérdida de ningún tipo de 
     *        accesorio (armas o potenciadores de escudo)
     * @return True si el daño representado no tiene ningún efecto y 
     *         False en otro caso
     */
    @Override
    public boolean hasNoEffect(){
        return ( (nShields == 0) && ( weapons.isEmpty() ) );
    }
    
    /**
     * @brief Función para representar una instancia de la clase Damage
     *        en un string
     * @return s String que representa una instancia de la clase Damage
     */
    @Override
    public String toString() {
        
        String s;
        
        String s_nShields = "- Numero de potenciadores de escudo a eliminar: " + nShields + "\n";
        
        String s_weapons = "- Coleccion de armas a eliminar: ";
        if( weapons == null || weapons.isEmpty() )
            s_weapons += "Ninguna\n";
        else
            s_weapons += weapons.toString() + "\n";
        
        s = s_nShields + s_weapons;
        
        return s;
    }
}