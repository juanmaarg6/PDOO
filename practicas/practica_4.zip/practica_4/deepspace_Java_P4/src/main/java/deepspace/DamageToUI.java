/**
 * @file DamageToUI.java
 * @author Profesor
 */
package deepspace;

/**
 * @brief Representación ToUI de Damage
 */
public abstract class DamageToUI {
    private int nShields;

    /**
     * @brief Constructor con un parámetro
     * @param d Instancia de la clase Damage
     */
    DamageToUI(Damage d) {
        nShields=d.getNShields();
    }

    /**
     * @brief Consultor del número de potenciadores de escudo a eliminar
     * @return nShields
     */
    public int getNShields() {
        return nShields;
    }
    
    /**
     * @brief Devuelve la información de la colección de armas concretas 
     *        a eliminar
     * @return String con la información de la colección de armas concretas 
     *         a eliminar
     */
    public abstract String getWeaponInfo(); 
}