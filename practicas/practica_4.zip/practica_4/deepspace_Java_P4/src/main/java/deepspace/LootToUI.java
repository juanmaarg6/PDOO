/**
 * @file LootToUI.java
 * @author Profesor
 */
package deepspace;

/**
 * @brief Representación ToUI de Loot
 */
public class LootToUI {
    private final int nSupplies;
    private final int nWeapons;
    private final int nShields;
    private final int nHangars;
    private final int nMedals;

    private final boolean getEfficient;
    private final boolean spaceCity;    
    
    /**
     * @brief Constructor con un parámetro
     * @param l Instancia de la clase Loot
     */
    LootToUI(Loot l) {
        nSupplies=l.getNSupplies();
        nWeapons=l.getNWeapons();
        nShields=l.getNShields();
        nHangars=l.getNHangars();
        nMedals=l.getNMedals();
        
        getEfficient=l.getEfficient();
        spaceCity=l.spaceCity();
    }  

    /**
     * @brief Consultor del número de suministros
     * @return nSupplies
     */
    public int getnSupplies() {
        return nSupplies;
    }

    /**
     * @brief Consultor del número de armas
     * @return nWeapons
     */
    public int getnWeapons() {
        return nWeapons;
    }

    /**
     * @brief Consultor del número de escudos
     * @return nShields
     */
    public int getnShields() {
        return nShields;
    }

    /**
     * @brief Consultor del número de hangares
     * @return nHangars
     */
    public int getnHangars() {
        return nHangars;
    }

    /**
     * @brief Consultor del número de medallas
     * @return nMedals
     */
    public int getnMedals() {
        return nMedals;
    }

    /**
     * @brief Consultor de si una estación espacial se
     *        transformará en una estación espacial eficiente
     * @return getEfficient
     */
    public boolean isGetEfficient() {
        return getEfficient;
    }

    /**
     * @brief Consultor de si una estación espacial se
     *        transformará en una ciudad espacial
     * @return spaceCity
     */
    public boolean isSpaceCity() {
        return spaceCity;
    }  
}