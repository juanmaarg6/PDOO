/**
 * @file SpaceFighter.java
 * @author Juan Manuel Rodríguez Gómez
 */
package deepspace;

/**
 * @brief Interfaz de juego utilizada para SpaceStation y EnemyStarShip
 */
public interface SpaceFighter {
    public float fire();
    public float protection();
    public ShotResult receiveShot(float shot);
}