/**
 * @file BetaPowerEfficientSpaceStationToUI.java
 * @author Profesor
 */
package deepspace;

/**
 * @brief Representación ToUI de BetaPowerEfficientSpaceStation
 */
public class BetaPowerEfficientSpaceStationToUI extends PowerEfficientSpaceStationToUI {

    /**
    * @brief Constructor con un parámetro
    * @param s Instancia de la clase BetaPowerEfficientSpaceStation
    */
    BetaPowerEfficientSpaceStationToUI(BetaPowerEfficientSpaceStation s) {
        super(s);
    }
    
    /**
    * @brief Consultor del nombre de la estación espacial eficiente beta
    * @return Nombre de la estación espacial eficiente beta
    */
    @Override
    public String getName () {
        return super.getName() + " (beta)";
    }   
}