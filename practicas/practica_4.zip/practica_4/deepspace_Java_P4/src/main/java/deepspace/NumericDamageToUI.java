/**
 * @file NumericDamageToUI.java
 * @author Profesor
 */
package deepspace;

/**
 * @brief Representación ToUI de NumericDamage
 */
public class NumericDamageToUI extends DamageToUI{
    private int nWeapons;

    /**
     * @brief Constructor con un parámetro
     * @param d Instancia de la clase NumericDamage
     */
    NumericDamageToUI(NumericDamage d) {
        super(d);
        nWeapons=d.getNWeapons();
    }

    /**
     * @brief Consultor del número de armas a eliminar
     * @return nWeapons
     */
    public int getNWeapons() {
        return nWeapons;
    } 
    
    /**
     * @brief Devuelve la información del número de armas a eliminar
     * @return String con la información del número de armas a eliminar
     */
    @Override
    public String getWeaponInfo() {
        return ""+nWeapons;
    }
}
