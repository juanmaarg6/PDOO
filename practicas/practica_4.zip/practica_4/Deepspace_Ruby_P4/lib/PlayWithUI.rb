#encoding:utf-8

# File: PlayWithUI.rb
# Author: Profesor

require_relative 'GameUniverse'
require_relative 'TextMainView'
require_relative 'Controller'

# Brief: Se lanza la interfaz de texto (UI) del juego. El procedimiento es el 
#        siguiente:
#           1. Crear una nueva Vista (DeepSpaceView) y asociarla a la interfaz 
#              de texto (TextMainView)
#           2. Crear una nueva Instancia de GameUniverse
#           3. Inicializar el controlador del juego
#           4. Asociar al controlador el modelo (GameUniverse) y la interfaz 
#              de texto (DeepSpaceView)
#           5. Iniciar partida llamando al Controller
class PlayWithUI
  
  def self.main 
    game = Deepspace::GameUniverse.new
    ui = View::TextMainView.instance
    controller = Controller::Controller.instance
    controller.setModelView(game,ui)
    controller.start();
  end
end # Class

PlayWithUI.main