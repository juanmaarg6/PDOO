#encoding:utf-8

# File: NumericDamage.rb
# Author: Juan Manuel Rodríguez Gómez

require_relative 'Damage'
require_relative 'NumericDamageToUI'

module Deepspace

    # Brief Representa el daño producido a una estación espacial por una nave 
    #        enemiga cuando se pierde un combate. Cada instancia indicará la 
    #        pérdida de una cantidad de potenciadores de escudo y una cantidad
    #        de armas.
    #        Es una clase Hija de Damage.
    #        Además de heredar el atributo de potenciadores de escudo a perder, 
    #        se implementa la cantidad de armas a perder con un contador
    class NumericDamage < Damage

        # new público
        public_class_method :new
    
        # Consultores de atributos
        attr_reader :nWeapons
    
        # Constructor con parámetros
        # Param nW: Número de armas a perder
        # Param nS: Número de potenciadores de escudo a perder
        def initialize(nW, nS)
            super(nS)
            @nWeapons = nW
        end
    
        # Brief: Devuelve una copia del objeto NumericDamage
        # Return: Copia del objeto NumericDamage
        def copy
            return NumericDamage.new(@nWeapons, @nShields)
        end
    
        public
    
        # Brief: Construye una nueva instancia NumericDamageToUI a partir de la propia 
        #        instancia que recibe el mensaje y lo devuelve.
        #        Estos objetos constituyen una capa que permite conectar el 
        #        modelo con la interfaz de usuario (NumericDamage) manteniendo 
        #        cierto nivel de aislamiento entre ambos niveles
        # Return: Instancia de la clase NumericDamageToUI
        def getUIversion
            return NumericDamageToUI.new(self)
        end
    
        # Brief: Devuelve una versión ajustada del objeto a las colecciones de 
        #        armas y potenciadores de escudos suministradas como parámetro.
        #        Partiendo del daño representado por el objeto que recibe este 
        #        mensaje, se devuelve una copia del mismo pero reducida si es 
        #        necesario para que no implique perder armas o potenciadores de 
        #        escudos que no están en las colecciones de los parámetros
        # Param w: Colección de armas disponibles
        # Param s: Colección de potenciadores de escudo disponibles
        # Return: NumericDamage ajustado
        def adjust(w, s)

            # Mínimo entre el número de potenciadores de escudo disponibles y el 
            # número de potenciadores de escudo a eliminar
            minNShields = adjustShieldBooster(s)

            # Mínimo entre el número de armas disponibles y el número de armas
            # a eliminar
            minNWeapons = [@nWeapons,w.length].min
        
            # Devolvemos el Damage ajustado con el número de potenciadores de 
            # escudo y el número de armas a eliminar
            return NumericDamage.new(minNWeapons, minNShields)
        end

        # Brief: Consultor del número de armas a eliminar
        # Return: nWeapons
        def nWeapons
            @nWeapons
        end
    
        # Brief: Decrementa en una unidad el contador de armas que deben ser 
        #        eliminadas. Ese contador no puede ser inferior a cero en ningún 
        #        caso
        # Param w: Arma cuyo tipo se va a eliminar de la lista de tipos concretos
        #          de armas disponibles, siempre que sea posible
        def discardWeapon(w)
            if(@nWeapons > 0)
                @nWeapons -= 1	
            end
        end
        
        # Brief: Devuelve True si el daño representado no tiene ningún efecto.
        #        Esto quiere decir que no implica la pérdida de ningún tipo de 
        #        accesorio (armas o potenciadores de escudo)
        # Return: True si el daño representado no tiene ningún efecto y 
        #         False en otro caso
        def hasNoEffect
            return (@nWeapons == 0 && super)
        end
    
        # Brief: Función para representar una instancia de la clase NumericDamage
        #        en un string
        # Return: String que representa una instancia de la clase NumericDamage
        def to_s

            s_nShields = "- Numero de potenciadores de escudo a eliminar: #{@nShields}\n"
            s_nWeapons = "- Numero de armas a eliminar: #{@nWeapons}\n"

            return s_nShields + s_nWeapons
        end
    end # Class
end # Module