#encoding:utf-8

# File: Damage.rb
# Author: Juan Manuel Rodríguez Gómez

require_relative 'WeaponType'
require_relative 'Weapon'
require_relative 'DamageToUI'

module Deepspace
    
    # Brief: Representa el daño producido a una estación espacial por una nave 
    #        enemiga cuando se pierde un combate. Cada instancia indicará la 
    #        pérdida de una cantidad de potenciadores de escudo y por otro lado, 
    #        o bien una cantidad de tipos indeterminados de armas o un conjunto 
    #        de tipos de armas concretas que se deben eliminar
    class Damage
        
        # Constructor con parámetros
        # Param nS: Número de potenciadores de escudo a perder
        def initialize(nS)
            @nShields = nS
        end

        # new privado
        private_class_method :new
        
        public

        # Brief: Construye una nueva instancia DamageToUI a partir de la propia 
        #        instancia que recibe el mensaje y lo devuelve.
        #        Estos objetos constituyen una capa que permite conectar el 
        #        modelo con la interfaz de usuario (Damage) manteniendo 
        #        cierto nivel de aislamiento entre ambos niveles
        # Return: Instancia de la clase DamageToUI
        def getUIversion
            return DamageToUI.new(self)
        end

        # Brief: Consultor del número de potenciadores de escudo a eliminar
        # Return: nShields
        def nShields
            @nShields
        end
        
        # Brief: Ajusta el número de potenciadores de escudo a perder
        # Param s: Coleccion de potenciadores de escudo
        # Return: Número de potenciadores de escudo a perder ajustado
        def adjustShieldBooster(s)

            # Mínimo entre el número de potenciadores de escudo disponibles y el 
            # número de potenciadores de escudo a eliminar
            return [@nShields,s.length].min
        end

        # Brief: Decrementa en una unidad el número de potenciadores de escudo que 
        #        deben ser eliminados. Ese contador no puede ser inferior a cero 
        #        en ningún caso
        def discardShieldBooster
            if (@nShields > 0)
                @nShields -= 1;
            end
        end
        
        # Brief: Devuelve True si el daño representado no tiene ningún efecto.
        #        Esto quiere decir que no implica la pérdida de ningún tipo de 
        #        accesorio (armas o potenciadores de escudo)
        # Return: True si el daño representado no tiene ningún efecto y 
        #         False en otro caso
        def hasNoEffect
            return (@nShields == 0)
        end
    end # Class
end # Module