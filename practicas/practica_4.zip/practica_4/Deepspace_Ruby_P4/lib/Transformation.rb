#encoding:utf-8

# File: Transformation.rb
# Author: Juan Manuel Rodríguez Gómez

module Deepspace

    # Brief: Representa las posibles transformaciones que puede sufrir una 
    #      estación espacial
    module Transformation
        NOTRANSFORM=:notransform
        GETEFFICIENT=:getefficicent
        SPACECITY=:spacecity
    end # Module Transformation
end # Module Deepspace