#encoding:utf-8

# File: Controller.rb
# Author: Profesor

require 'singleton'

module Controller
  
  DS=Deepspace

# Brief: Esta clase de carácter Singleton representa un controlador que permite 
#        conectar la interfaz visible para el usuario (ya sea gráfica o de 
#        texto) con el modelo (en este caso GameUniverse).
# 
#        Para ello se disponen una serie de métodos que permiten controlar  
#        las diferentes funcionalidades básicas del juego
class Controller
  
  include Singleton
  
  @@WEAPON = 0x1
  @@SHIELD = 0x2
  @@HANGAR = 0x4
  
  # Consultor de WEAPON
  def self.WEAPON
    @@WEAPON
  end
  
  # Consultor de SHIELD
  def self.SHIELD
    @@SHIELD
  end

  # Consultor de HANGAR
  def self.HANGAR
    @@HANGAR
  end

    # Consultores
    attr_reader :model, :view
    
    # Constructor sin parámetros
    def initialize ()
      @model = nil
      @view = nil
    end
    
    public
    
    # Brief: Asocia una instancia de Juego y una instancia de Vista al 
    #        controlador
    # Param aGame: Instancia de la clase GameUniverse
    # Param aView: Instancia de la clase DeepSpaceView
    def setModelView (aModel, aView)
      @model = aModel
      @view = aView
    end
    
    # Brief: Inicia una nueva partida
    def start() 
        @model.init(@view.readNamePlayers())
        @view.updateView()
        @view.showView()
    end
    
    # Brief: Finaliza la partida y detiene la ejecución del programa
    # Param i: Flag de salida con estado final de ejecución (normalmente 0)
    def finish(i)
      if @view.confirmExitMessage()
        exit(i)
      end
    end

    # Brief: Comprueba si se puede pasar de turno
    # Return: True (1) si se puede pasar de turno y False (0) si no se puede
    def nextTurn() 
        nextTurnAllowed = @model.nextTurn()
        if !nextTurnAllowed
          @view.nextTurnNotAllowedMessage()
        end
        return nextTurnAllowed
    end

    # Combate entre una estación espacial y un enemigo
    def combat() 
        result = @model.combat()
        case result
        when DS::CombatResult::ENEMYWINS
          @view.lostCombatMessage()
        when DS::CombatResult::STATIONESCAPES
          @view.escapeMessage()
        when DS::CombatResult::STATIONWINS
          @view.wonCombatMessage()
          if @model.haveAWinner()
            @view.wonGameMessage()
            exit(0)
          end
        when DS::CombatResult::STATIONWINSANDCONVERTS
          @view.wonConvertCombatMessage()
        when DS::CombatResult::NOCOMBAT
          @view.noCombatMessage()
        end
    end

    # Brief: Construye una nueva instancia GameUniverseToUI a partir de la 
    #        propia instancia que recibe el mensaje y lo devuelve.
    #        Estos objetos constituyen una capa que permite conectar el 
    #        modelo con la interfaz de usuario (GameUniverse) manteniendo 
    #        cierto nivel de aislamiento entre ambos niveles
    # Return: Instancia de la clase GameUniverseToUI
    def getUIversion() 
        return @model.getUIversion()
    end

    # Brief: onsultor del estado actual del juego
    # Return: state
    def getState() 
        return @model.state()
    end
    
    private
    
    # Brief: Invierte un array de números enteros
    # Param array: Array de números enteros a invertir
    def invertArray (array)
      array.reverse!
    end

    public
    
    # Brief: Descarta el hangar del jugador actual
    def discardHangar() 
        @model.discardHangar()
        @view.updateView()
    end

    # Brief: Monta los objetos que se pasan como parámetros
    # Param weapons: Array de índices de las armas a montar
    # Param shields: Array de índices de los potenciadores de escudo a montar
    def mount (weapons, shields) 
      invertArray (weapons);
      invertArray (shields);
    
      for i in weapons
        @model.mountWeapon(i)
      end
      
      for i in shields
        @model.mountShieldBooster(i)
      end
    end
    
    # Brief: Descarta los objetos pasados como parámetros
    # Param places: Flag que permite indicar de dónde se descartan 
    #               (WEAPON | SHIELD | HANGAR)
    # Param weapons: Array de índices de las armas a descartar
    # Param shields: Array de índices de los potenciadores de escudo a 
    #                descartar
    def discard (places, weapons, shields) 
      invertArray(weapons);
      invertArray(shields);
    
      if ((places & Controller.WEAPON) == Controller.WEAPON) 
        for i in weapons
          @model.discardWeapon(i)
        end
      elsif ((places & Controller.SHIELD) == Controller.SHIELD)
        for i in shields
          @model.discardShieldBooster(i)
        end
      elsif ((places & Controller.HANGAR) == Controller.HANGAR)
        for i in weapons
          @model.discardWeaponInHangar(i)
        end
        for i in shields
          @model.discardShieldBoosterInHangar(i)
        end
      end
    end
    
end # Class

end # Module