#encoding:utf-8

# File: SpaceCity.rb
# Author: Profesor

require_relative 'SpaceStation'
require_relative 'Transformation'
require_relative 'SpaceCityToUI'

module Deepspace

    # Brief: Representa la transformación de estaciones espaciales en 
    #        ciudades espaciales. 
    #        Las ciudades espaciales están formadas por la estación que tenía el 
    #        jugador y las estaciones espaciales del resto de jugadores. 
    #        Son a su vez un tipo de estación espacial
    class SpaceCity < SpaceStation
    
        # Brief: Constructor con parámetros
        # Param base: Estación espacial base de la ciudad
        # Param rest: Colaboradores de la ciudad espacial
        def initialize(base, rest)
            newCopy(base)
            @base = base
            @collaborators = rest
        end

        # Brief: Consultor del tipo de arma
        # Return: type
        def collaborators
            return @collaborators
        end
    
        # Brief: Realiza un disparo entre todas las estaciones que forman la
        #        ciudad espacial y se devuelve la energía o potencia del mismo
        # Return: La potencia del disparo
        def fire
            factor = @base.fire

            @collaborators.each { |nave|
                factor += nave.fire
            }
        
            return factor
        end
    
        # Brief: Se usa el escudo de protección de todas las estaciones que 
        #        forman la ciudad espacial y se devuelve la energía del mismo
        # Return: La energía del escudo de protección
        def protection
            factor = @base.protection

            @collaborators.each { |nave|
                factor += nave.protection
            }
            
            return factor
        end
    
        # Brief: Recepción de un botín para la base de la ciudad espacial
        # Param loot: Botín a recibir
        # Return: La ciudad espacial no puede volver a transformarse
        def setLoot(loot)
            super
            return Transformation::NOTRANSFORM
        end

        # Brief: Construye una nueva instancia SpaceCityToUI a partir de la propia 
        #        instancia que recibe el mensaje y lo devuelve.
        #        Estos objetos constituyen una capa que permite conectar el 
        #        modelo con la interfaz de usuario (SpaceCity) manteniendo 
        #        cierto nivel de aislamiento entre ambos niveles
        # Return: Instancia de la clase SpaceCityToUI
        def getUIversion
            return SpaceCityToUI.new(self)
        end
    
        # Brief: Función para representar una instancia de la clase SpaceCity
        #        en un string
        # Return: String que representa una instancia de la clase SpaceCity
        def to_s

            s_base = "- Estacion Espacial Base de la Ciudad Espacial: " + @base.to_s + "\n";

            s_collaborators = "- Colaboradores de la Ciudad Espacial: \n";        
            @collaborators.each { |estacion|
                s_collaborators += estacion.to_s
            }
      
            return s_base + s_collaborators
        end
    end # Class
end # Module