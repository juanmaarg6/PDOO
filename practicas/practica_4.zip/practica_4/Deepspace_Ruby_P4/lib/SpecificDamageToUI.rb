#encoding:utf-8

# File: NumericDamageToUI.rb
# Author: Profesor

require_relative 'DamageToUI'

module Deepspace

# Brief: Representación ToUI de SpecificDamage
class SpecificDamageToUI < DamageToUI
  
  # new público
  public_class_method :new
  
  # Consultor de la colección de armas concretas a eliminar
  attr_reader :weapons
  
  # Brief: Constructor con un parámetro
  # Param d: Instancia de la clase SpecificDamage
  def initialize (d)
    super(d)
    @weapons=Array.new(d.weapons)
  end
    
  public
  
  # Brief: Devuelve la información de la colección de armas concretas a eliminar
  # Return: String con la información de la colección de armas concretas a eliminar
  def getWeaponInfo() 
      return "[" + @weapons.join(", ") + "]"
  end
  
end # Class

end # Module