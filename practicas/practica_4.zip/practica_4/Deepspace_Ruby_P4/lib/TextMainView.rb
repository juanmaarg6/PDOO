#encoding:utf-8

# File: TextMainView.rb
# Author: Profesor

require 'singleton'

require_relative 'Controller'
require_relative 'Command'

module View
  
  class Value

    # Consultor
    attr_reader :text

    # Brief: Constructor con un parámetro
    # Param aText: Texto a mostrar por pantalla
    def initialize(aText)
      @text = aText
    end
  end # class Value
  
  # Brief: Enumerado que permite elegir entre los diferentes elementos 
  #        del juego. Consta de WEAPON | SHIELD | HANGAR
  module Element
    WEAPON = Value.new("Arma")
    SHIELD = Value.new("Escudo")
    HANGAR = Value.new("Hangar")
  end # Module Element
  
  # Brief: Enumerado que permite elegir los dos tipos de operaciones 
  #        principales del juego. Consta de MOUNT | DISCARD
  module Operation
    MOUNT = Value.new("Montar")
    DISCARD = Value.new("Descartar")
  end # Module Operation
  
  DS=Deepspace
  CT=Controller
  
# Brief: Esta clase de carácter Singleton representa la interfaz que verá el 
#        usuario (UI) en formato de texto. A través de varias salidas de tipo 
#        texto y con el menú de opciones, el usuario podrá controlar las 
#        diferentes acciones del juego
class TextMainView
  
  include Singleton
  
  @@mainSeparator = "\n ******* ******* ******* ******* ******* ******* ******* \n"
  @@separator = "\n ------- ------- ------- ------- ------- ------- ------- \n"
  
  
  # Brief: Constructor sin parámetros
  def initialize()
    @gameUI = nil
    @state = nil
  end
  
  private
  
  # Brief: Genera una pausa entre dos acciones transcurridas en el juego
  # Param s: Título de la pausa
  def pause(s) 
    print @@mainSeparator
    print @@mainSeparator
    puts s
    print @@mainSeparator
    print @@mainSeparator
    print "\n(pulsa  ENTER  para continuar) "
    gets
  end

  # Brief: Procesa una instrucción del menu de opciones
  # Param command: Objeto del enumerado Command
  def processCommand(command) 
    case command
      when Command::EXIT 
        CT::Controller.instance.finish(0)
      when Command::SHOWSTATION 
        puts showStation(@gameUI.currentStation)
      when Command::SHOWENEMY
        puts showEnemy(@gameUI.currentEnemy)
      when Command::MOUNTWEAPONS 
        mountDiscardFromHangar(Operation::MOUNT, Element::WEAPON)
      when Command::MOUNTSHIELDS 
        mountDiscardFromHangar(Operation::MOUNT, Element::SHIELD)
      when Command::DISCARDWEAPONSINHANGAR 
        mountDiscardFromHangar(Operation::DISCARD, Element::WEAPON)
      when Command::DISCARDSHIELDSINHANGAR 
        mountDiscardFromHangar(Operation::DISCARD, Element::SHIELD)
      when Command::DISCARDHANGAR 
        CT::Controller.instance.discardHangar()
        pause("\n ******* Hangar Completo Descartado ******* ")
      when Command::DISCARDWEAPONS 
        discardMountedElements(Element::WEAPON)
      when Command::DISCARDSHIELDS 
        discardMountedElements(Element::SHIELD)
      when Command::COMBAT 
        puts "Combatiendo"
        CT::Controller.instance.combat()
      when Command::NEXTTURN 
        CT::Controller.instance.nextTurn()
    end
  end
  
  # Brief: Lee un entero y comprueba que se ha introducido correctamente
  # Param message: Mensaje a mostrar al usuario
  # Param min: Valor mínimo posible de elección
  # Param max: Valor máximo posible de elección
  def readInt (message, min, max) 
    number = -1
    begin
      valid = true
      print message
      input = gets.chomp
      begin  
        number = Integer(input)
        if (number<min || number>max)  # No es un entero entre los válidos
          puts "\nEl numero debe estar entre #{min} y #{max}\n"
          valid = false
        end
      rescue Exception => e # No se ha introducido un entero
        puts "\nDebes introducir un numero.\n"
        valid = false;  
      end
      if !valid
        puts "\n\nInténtalo de nuevo.\n\n"
      end
    end while !valid
    return number
  end
  
  public
  
  # Brief: Actualiza la vista de texto
  def updateView()
    @gameUI = CT::Controller.instance.getUIversion()
    @state = CT::Controller.instance.getState()
  end
  
  # Brief: Muestra la vista de texto al usuario
  def showView() 
    while true # Hasta que se elija en el menú  Salir
      updateView()
      command = Command::EXIT;
      case @state
        when DS::GameState::INIT
          command = getCommandInit()
        when DS::GameState::BEFORECOMBAT 
          command = getCommandBeforeCombat()
        when DS::GameState::AFTERCOMBAT 
          command = getCommandAfterCombat()
      end
      processCommand (command)
    end
  end
  
  # Brief: Lee el número de jugadores que hay en total
  # Return: ArrayList con los nombres de los jugadores
  def readNamePlayers() 
    names = Array.new
    nPlayers = readInt("\n¿Cuántos jugadores participan (2-4)? ",2,4)
    for i in 0...nPlayers
      print "Escribe el nombre del jugador #{i+1}: "
      names.push(gets.chomp)
    end
    return names
  end
  
  # Brief: Advierte al usuario si quiere salir del juego
  # Return: True (1) si el usuario decide salir y False (0) en otro caso
  def confirmExitMessage() 
    print "¿Estás segur@ que deseas salir [s/N]? "
    fullInput = gets.chomp
    if !fullInput.empty?
      input = fullInput[0]
      if input == 's' || input == 'S'
        return true
      end
    end
    return false;
  end
  
  private
  
  # Brief: Muestra el menú de opciones
  # Param message: Mensaje a mostrar al usuario
  # Param menu: Menú de opciones disponibles a elegir
  def manageMenu(message, menu) 
    menuCheck = Hash.new   # Para comprobar que se hace una selección válida

    for c in menu do
      menuCheck [c.menu] = c
    end
    begin # Until a valid selection
      validInput = true
      option = Command::GOBACK.menu;
      puts @@separator
      puts "**** " + message + " ****\n"
      for c in menu do 
        puts '%3d' % [c.menu] + " : " + c.text + "\n"
      end
      print "\n Elige una opción: "
      capture = gets.chomp
      begin
        option = Integer(capture)
        if(! menuCheck.has_key?(option)) then # It's not a valid integer
          validInput = false;
        end
      rescue Exception => e
        validInput = false;
      end
      if(!validInput) then
        inputErrorMessage()
      end
    end while(! validInput)
    return(menuCheck[option])    
  end
  
  # Brief: Descarta elementos del hangar
  # Param operation: Objeto del enumerado Operation
  # Param element: Objeto del enumerado Element
  def mountDiscardFromHangar(operation, element) 
      option = Command::GOBACK.menu
      elements = Array.new
      noElements = Array.new
      
      begin    # Choice and mount weapons or shields until go back
        howMany = showHangarToMountDiscard(operation, element)
        option = getChoice(howMany)
        elements.clear
        if option != Command::ERRORINPUT.menu
          elements.push(option)
        end
        case element
        when Element::WEAPON
          if operation == Operation::MOUNT
            CT::Controller.instance.mount(elements,noElements)
          else 
            CT::Controller.instance.discard(CT::Controller.HANGAR,elements,noElements)
          end
        when Element::SHIELD
          if operation == Operation::MOUNT
            CT::Controller.instance.mount(noElements,elements)
          else 
            CT::Controller.instance.discard(CT::Controller.HANGAR,noElements,elements)
          end
        end
        updateView()
      end while(option != Command::GOBACK.menu)
  end
  
  public 

  # Brief: Muestra al usuario que no puede pasar de turno
  def nextTurnNotAllowedMessage() 
    puts "\n No puedes avanzar de turno, no has cumplido tu castigo"
  end
  
  private
  
  # Brief: Pide un entero para después realizar una de las operaciones 
  #        del menú disponibles
  # Param howMany: Flag que permite ver las diferentes opciones
  # Return: Opción realizada
  def getChoice(howMany) 
    validInput = true
    option = Command::GOBACK.menu
    print("\n Elige: ")
    capture = gets.chomp
    begin
      option = Integer(capture)
      if(option < Command::GOBACK.menu || option > howMany) then  # no se ha escrito un entero en el rango permitido
        validInput = false
      end
    rescue Exception => e   # no se ha escrito un entero
      validInput = false;
    end
    if(! validInput) then
      inputErrorMessage()
      return Command::ERRORINPUT.menu
    end
    return option;
  end
  
  # Brief: Procesa las diferentes opciones del menú tras iniciar la partida
  # Return: Opciones del menu tras iniciar una partida
  def getCommandInit() 
    commands = [Command::SHOWSTATION, Command::MOUNTWEAPONS, Command::MOUNTSHIELDS, Command::COMBAT, Command::EXIT]
    return manageMenu("Bienvenido  " + @gameUI.currentStation.name + \
             ",  es tu primera vez.\n Organiza tu Armamento para el Combate.\n --- Opciones disponibles", \
             commands)
  end
  
  # Brief: Procesa las diferentes opciones del menú antes de un combate
  # Return: Opciones del menu antes de un combate
  def getCommandBeforeCombat() 
    commands = [Command::SHOWSTATION, Command::COMBAT, Command::EXIT]
    return manageMenu(@gameUI.currentStation.name + \
            ",  estás en un punto de no retorno.\n Solo te queda Combatir.", commands)
  end

  # Brief: Procesa las diferentes opciones del menú tras un combate
  # Return: Opciones del menú tras un combate
  def getCommandAfterCombat()
    commands = [ Command::SHOWSTATION, 
          Command::MOUNTWEAPONS, Command::MOUNTSHIELDS, 
          Command::DISCARDWEAPONS, Command::DISCARDSHIELDS,
          Command::DISCARDWEAPONSINHANGAR, Command::DISCARDSHIELDSINHANGAR,
          Command::DISCARDHANGAR, 
          Command::SHOWENEMY, Command::NEXTTURN, Command::EXIT ]
      
      return manageMenu(@gameUI.currentStation.name + \
              ",  puedes Reorganizar tu Armamento antes de pasar de turno.\n Opciones disponibles", \
              commands)
  end
  
  # Brief: Mensaje de error tras no hacer una selección válida
  def inputErrorMessage()
    puts "\n\n ¡¡¡ E R R O R !!! \n\n Selección errónea. Inténtalo de nuevo.\n\n"
  end
  
  public 
  
  # Brief: Mensaje tras perder un combate
  def lostCombatMessage() 
    puts "Has PERDIDO el combate. \tCumple tu castigo."
  end
  
  private 
  
  # Brief: Descarta, entre los objetos montados, el elemento pasado como parámetro
  # Param element: Elemento a descartar
  def discardMountedElements(element) 
      howMany = 0
      option = Command::GOBACK.menu
      elements = Array.new
      noElements = Array.new
      
      begin   # Choice and discard weapons or shields until go back
        puts @@separator
        puts "Elige un " + element.text + " para Descartar"
        puts "\n" + format("%3d",Command::GOBACK.menu) + " : " + Command::GOBACK.text + "\n"
        case element
            when Element::WEAPON 
                puts showWeapons(@gameUI.currentStation.weapons, true)
                howMany = @gameUI.currentStation.weapons.size();
            when Element::SHIELD 
                puts showShields(@gameUI.currentStation.shieldBoosters, true)
                howMany = @gameUI.currentStation.shieldBoosters.size()
        end
        option = getChoice(howMany)
        elements.clear()
        if (option != Command::ERRORINPUT.menu)
          elements.push(option)
        end
        case element
        when Element::WEAPON 
          CT::Controller.instance.discard(CT::Controller.WEAPON, elements, noElements)
        when Element::SHIELD 
          CT::Controller.instance.discard(CT::Controller.SHIELD, noElements, elements)
        end
        updateView()
    end while(option != Command::GOBACK.menu)
  end
  
  public
  
  # Brief: Mensaje de huida de un combate
  def escapeMessage()
    puts "Has logrado escapar. \tEres una Gallina Espacial."
  end

  # Brief: Mensaje de victoria tras un combate
  def wonCombatMessage()
    puts "Has GANADO el combate. \tDisfruta de tu botín."
  end

  # Brief: Mensaje de conversión de una estación espacial a una 
  #        ciudad espacial o a una estación espacial eficiente
  def wonConvertCombatMessage
    if @gameUI.currentEnemy.loot.efficient
      puts "Has GANADO el combate. \nAdemás te has CONVERTIDO en una ESTACIÓN ESPACIAL EFICIENTE. \nDisfruta de tu botín"
    else
      puts "Has GANADO el combate. \nAdemás te has CONVERTIDO en una CIUDAD ESPACIAL. \nDisfruta de tu botín"
    end
  end
  
  # Brief: Mensaje de victoria del juego por parte del jugador actual
  def wonGameMessage() 
    puts "\n\tHAS GANADO LA PARTIDA"
  end
    
  # Brief: Mensaje de imposibilidad de combatir
  def noCombatMessage()
    puts "No puedes combatir en este momento"
  end
  
  # Brief: Se muestra por pantalla la instancia de la estación actual
  # Param station: Objeto SpaceStationToUI actual
  # Return: out String con la información de la estación actual
  def showStation(station) 
    out = ""

    out += @@mainSeparator + "\n"
    out += " ***** Información de la  Estación Espacial Actual *****\n"
    out += "       -------------------------------------------\n"
    out += "Nombre ............ : " + station.name + "\n"
    out += "Potencia de fuego . : " + station.ammoPower.to_s + "\n"
    out += "Potencia de defensa : " + station.shieldPower.to_s + "\n"
    out += "Medallas .......... : " + station.nMedals.to_s + "\n"
    out += "Armas montadas : \n"
    tmp = showWeapons(station.weapons, false)
    if("".eql?(tmp)) then
        out += "   Ninguna \n"
    else
        out += tmp
    end
    out += "Potenciadores de Escudos montados : \n"
    tmp = showShields(station.shieldBoosters(), false)
    if("".eql?(tmp))
        out += "   Ninguno \n"
    else
        out += tmp
    end
    out += showHangar(station.hangar)
    out += "Castigo pendiente : "
    out += showDamage(station.pendingDamage)
    return out
  end
  
  # Brief: Muestra las armas montadas
  # Param someWeapons: ArrayList con armas
  # Param menu: Valor booleano para mostrar un tipo de representación u otra
  # Return: out String con las armas montadas
  def showWeapons(someWeapons, menu) 
    out = "";

    i = 0;
    for aWeapon in someWeapons do
      out += showWeapon(aWeapon,(menu ?(format("%3d",i) + " : ") : " - "))
      i+=1
    end
    return out
  end
  
  # Brief: Muestra un arma
  # Param aWeapon: Arma a mostrar
  # Param tab: Tabulación
  # Return: String con el arma
  def showWeapon(aWeapon, tab) 
    return(tab + aWeapon.type.to_s + " - Potencia: " + aWeapon.power.to_s + " - Usos: " + aWeapon.uses.to_s + "\n")
  end

  # Brief: Muestra los escudos montados
  # Param someShields: ArrayList con escudos
  # Param menu: Valor booleano par mostrar un tipo de representación u otra
  # Return: out String con los escudos montados
  def showShields(someShields, menu) 
    out = ""
    
    i = 0
    for aShield in someShields do
      out += showShield(aShield,(menu ?('%3d' % [i]) + " : " : " - "))
      i+=1
    end
    return out
  end
  
  # Brief: Muestra un escudo
  # Param aShield: Escudo a mostrar
  # Param tab: Tabulación
  # Return: String con el escudo
  def showShield(aShield, tab) 
      return(tab + "Escudo - Potencia: " + aShield.boost.to_s + " - Usos: " + aShield.uses.to_s + "\n");
  end
  
  # Brief: Muestra un hangar
  # Param aHangar: Hangar a mostrar
  # Return: out String con el hangar
  def showHangar(aHangar) 
    String out = "";
    if(aHangar != nil) then
        slots = aHangar.maxElements
        out += "Dispone de un Hangar con " + slots.to_s
        out +=(slots == 1 ? " lugar \n" : " lugares \n")
        out += showWeapons(aHangar.weapons, false)
        out += showShields(aHangar.shieldBoosters, false)
    else
      out = "No tiene ningún Hangar\n"
    end
    return out
  end
  
  # Brief: Muestra un enemigo
  # Param anEnemy: Enemigo a mostar
  # Return: out String con el enemigo
  def showEnemy(anEnemy) 
    out = ""
    out += @@separator + "\n"
    out += " *** Información del Enemigo actual ***\n"
    out += "     ------------------------------\n"
    out += "Nombre ............ : " + anEnemy.name + "\n"
    out += "Potencia de fuego . : " + anEnemy.ammoPower.to_s + "\n"
    out += "Potencia de defensa : " + anEnemy.shieldPower.to_s + "\n"
    out += "Botín : \n"
    out += showLoot(anEnemy.loot)
    out += "Pérdidas : \n"
    out += showDamage(anEnemy.damage)
    return out
  end
  
  # Brief: Muestra un Loot
  # Param aLoot: Loot a mostrar
  # Return: out String con el loot
  def showLoot(aLoot) 
      out = ""
      out += " - Armas ..... : " + aLoot.nWeapons.to_s + "\n"
      out += " - Escudos ... : " + aLoot.nShields.to_s + "\n"
      out += " - Hangares .. : " + aLoot.nHangars.to_s + "\n"
      out += " - Suministros : " + aLoot.nSupplies.to_s + "\n"
      out += " - Medallas .. : " + aLoot.nMedals.to_s + "\n"
      return out
  end
  
  # Brief: Muestra un Damage
  # Param aDamage: Damage a Mostrar
  # Return: out String con el Damage
  def showDamage(aDamage)
      if (aDamage != nil) then
        out = "\n"
        out += " - Armas . : " + aDamage.getWeaponInfo() + "\n"
        out += " - Escudos : " + aDamage.nShields.to_s + "\n"
      else
        out = "Ninguno\n"
      end
      return out
  end
  
  # Brief: Muestra un menú para montar/descartar armas/escudos
  # Param operation: Operación a realizar [Montar | Descartar]
  # Param element: Elemento a realizar operación [Weapon | ShieldBooster]
  # Return: Entero con la opción realizada
  def showHangarToMountDiscard(operation, element) 
      option = Command::GOBACK.menu
      
      puts @@separator
      puts "Elige un " + element.text + " para " + operation.text
      puts "\n" + format("%3d",Command::GOBACK.menu) + " : " + Command::GOBACK.text + "\n"
      hangar = @gameUI.currentStation.hangar
      if (hangar != nil) then
        case(element) 
            when Element::WEAPON 
                for weapon in hangar.weapons do
                    option+=1
                    print showWeapon(weapon, format("%3d",option) + " : ")
                end
        when Element::SHIELD 
                for shield in hangar.shieldBoosters do
                    option+=1
                    print showShield(shield, format("%3d",option) + " : ")
                end
        end
      end
      return option
  end

  end # Class TextMainView
  
end # Module View