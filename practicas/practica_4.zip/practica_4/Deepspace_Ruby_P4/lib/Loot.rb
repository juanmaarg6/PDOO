#encoding:utf-8

# File: Loot.rb
# Author: Juan Manuel Rodríguez Gómez

require_relative 'LootToUI'

module Deepspace

    # Brief: Representa el botín que se obtiene al vencer a una nave enemiga. 
    #        Puede incluir cantidades que representen un número de paquetes de 
    #        suministros, armas, potenciadores de escudo, hangares y/o medallas.
    class Loot
        
        # Brief: Constructor con parámetros
        # Param nsu: Número de suministros
        # Param nw: Número de armas
        # Param nsh: Número de escudos
        # Param nh: Número de hangares
        # Param nm: Número de medallas
        # Param ef: Estación espacial se convertirá o no en eficiente
        # Param city: Se creará o no una ciudad espacial
        def initialize(nsu, nw, nsh, nh, nm, ef=false, city=false)
            @nSupplies = nsu
            @nWeapons = nw
            @nShields = nsh
            @nHangars = nh
            @nMedals = nm
            @efficient = ef
            @spaceCity = city
        end
        
        public
        
        # Brief: Consultor del número de suministros
        # Return: nSupplies
        def nSupplies
            @nSupplies
        end
        
        # Brief: Consultor del número de armas
        # Return: nWeapons
        def nWeapons
            @nWeapons
        end
        
        # Brief: Consultor del número de escudos
        # Return: nShields
        def nShields
            @nShields
        end
        
        # Brief: Consultor del número de hangares
        # Return: nHangars
        def nHangars
            @nHangars
        end
        
        # Brief: Consultor del número de medallas
        # Return: nMedals
        def nMedals
            @nMedals
        end

        # Brief: Consultor de si una estación espacial pasará a ser eficiente o no
        # Return: efficient
        def efficient
            @efficient
        end

        # Brief: Consultor de si se creará o no una ciudad espacial
        # Return: spaceCity
        def spaceCity
            @spaceCity
        end

        # Brief: Construye una nueva instancia LootToUI a partir de la propia 
        #        instancia que recibe el mensaje y lo devuelve.
        #        Estos objetos constituyen una capa que permite conectar el 
        #        modelo con la interfaz de usuario (Loot) manteniendo cierto nivel 
        #        de aislamiento entre ambos niveles
        # Return: Instancia de la clase LootToUI
        def getUIversion
            return LootToUI.new(self)
        end
      
        #Brief : Funcion de depuracion
        #Return : Representacion de la instancia pasada a cadena String
        def to_s
            
            s_nSupplies = "- Numero de suministros: #{@nSupplies} \n"
            s_nWeapons = "- Numero de armas: #{@nWeapons} \n"
            s_nShields = "- Numero de escudos: #{@nShields} \n"
            s_nHangars = "- Numero de hangares: #{@nHangars}\n"
            s_nMedals = "- Numero de medallas: #{@nMedals} \n"
            
            return s_nSupplies + s_nWeapons + s_nShields + s_nHangars + s_nMedals
        end
      
    end # Class
end # Module
