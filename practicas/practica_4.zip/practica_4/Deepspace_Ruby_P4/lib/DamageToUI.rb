#encoding:utf-8

# File: DamageToUI.rb
# Author: Profesor

module Deepspace

# Brief: Representación ToUI de Damage
class DamageToUI
  
  private_class_method :new
  
  attr_reader :nShields
  
  # Brief: Constructor con un parámetro
  # Param d: Instancia de la clase Damage
  def initialize (d) 
    @nShields=d.nShields
  end
    
  public
  
  # Brief: Devuelve la información de la colección de armas concretas 
  #        a eliminar
  # Return: String con la información de la colección de armas concretas 
  def getWeaponInfo() 
    raise "ERROR: This method has not been implemented yet!"
  end
  
  # Brief: Función para representar una instancia de la clase DamageToUI
  #        en un string
  # Return: out String que representa una instancia de la clase DamageToUI
  def to_s
    out = "Weapons: " + getWeaponInfo() + ", Shields: #{@nShields}"
  end
  
end # Class

end # Module