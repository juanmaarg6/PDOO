#encoding:utf-8

# File: BetaPowerEfficientSpaceStationToUI.rb
# Author: Profesor

require_relative 'PowerEfficientSpaceStationToUI'

module Deepspace

# Brief: Representación ToUI de BetaPowerEfficientSpaceStation
class BetaPowerEfficientSpaceStationToUI < PowerEfficientSpaceStationToUI

    # Brief: Constructor con un parámetro
    # Param s: Instancia de la clase BetaPowerEfficientSpaceStation
    def initialize (s)
      super(s)
    end
    
    # Brief: Consultor del nombre de la estación espacial eficiente beta
    # Return: Nombre de la estación espacial eficiente beta
    def name
      return super + " (beta)"
    end

end # Class

end # Module