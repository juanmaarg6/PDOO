#encoding:utf-8

# File: SpaceCityToUI.rb
# Author: Profesor

require_relative 'SpaceStationToUI'

module Deepspace

# Brief: Representación ToUI de SpaceCity
class SpaceCityToUI < SpaceStationToUI 
  
  # Consultor
  attr_reader :collaborators
  
  # Brief: Constructor con un parámetro
  # Param city: Instancia de la clase SpaceCity
  def initialize (city) 
    super(city)
    @collaborators=Array.new
    for c in city.collaborators do 
      @collaborators << SpaceStationToUI.new(c)
    end
  end
  
  # Brief: Consultor del nombre de la ciudad espacial
  # Return: Nombre de la ciudad espacial
  def name () 
    return super + " (CIUDAD ESPACIAL)"
  end
  
  # Brief: Función para representar una instancia de la clase SpaceCityToUI
  #        en un string
  # Return: out String que representa una instancia de la clase SpaceCityToUI
  def to_s
    out = super
    out += "\n ------- My Collaborators are:"
    for c in @collaborators do
      out += "\n --- Collaborator --- \n"
      out += c.to_s
    end
    out += "\n ------- No More Collaborators \n"
    return out
  end

end # Class

end # Module