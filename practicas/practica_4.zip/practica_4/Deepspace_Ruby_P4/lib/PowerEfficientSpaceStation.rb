#encoding:utf-8

# File: PowerEfficientSpaceStation.rb
# Author: Juan Manuel Rodríguez Gómez

require_relative 'SpaceStation'
require_relative 'Transformation'
require_relative 'PowerEfficientSpaceStationToUI'

module Deepspace
    
    # Brief: Representa una estación espacial eficiente. Este tipo de estaciones
    #        espaciales consiguen que se incremente la potencia de disparo y de
    #        protección en un determinado factor constante respecto a las 
    #        estaciones estándar. Estas no pueden transformarse en ciudades
    #        espaciales
    #        Es una clase Hija de SpaceStation
    class PowerEfficientSpaceStation < SpaceStation
        
        # Constante
        @@EFFICIENCYFACTOR=1.10
    
        # Brief: Constructor con un parámetro
        # Param station: Instancia de la clase SpaceStation
        def initialize(station)
            newCopy(station)
        end
        
        # Brief: Realiza un disparo y se devuelve la energía o potencia del mismo. 
        #        La potencia de dicho disparo se ve incrementada por un
        #        factor constante
        # Return: La potencia del disparo incrementada
        def fire
            return super * @@EFFICIENCYFACTOR
        end
        
        # Brief: Se usa el escudo de protección y se devuelve la energía del mismo. 
        #        La energia de dicho escudo de protección se ve incrementada por 
        #        un factor constante
        # Return: La energía del escudo de protección incrementada
        def protection
            return super * @@EFFICIENCYFACTOR
        end
    
        # Brief: Recepción de un botín
        # Param loot: Botín a recibir
        # Return: Transformación de la estación espacial
        def setLoot(loot)
            super
      
            if loot.efficient
                return Transformation::GETEFFICIENT
            else
                return Transformation::NOTRANSFORM
            end
        end

        # Brief: Construye una nueva instancia PowerEfficientSpaceStationToUI a partir de la propia 
        #        instancia que recibe el mensaje y lo devuelve.
        #        Estos objetos constituyen una capa que permite conectar el 
        #        modelo con la interfaz de usuario (PowerEfficientSpaceStation) manteniendo 
        #        cierto nivel de aislamiento entre ambos niveles
        # Return: Instancia de la clase PowerEfficientSpaceStationToUI
        def getUIversion
            return PowerEfficientSpaceStationToUI.new(self)
        end
    
        # Brief Función para representar una instancia de la clase 
        #        PowerEfficientSpaceStation en un string
        # Return: String que representa una instancia de la clase 
        #           PowerEfficientSpaceStation
        def to_s
            return "- Estacion espacial eficiente: \n" + super;
        end
    end # Class
end # Module