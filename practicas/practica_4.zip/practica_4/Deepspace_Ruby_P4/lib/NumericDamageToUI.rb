#encoding:utf-8

# File: NumericDamageToUI.rb
# Author: Profesor

require_relative 'DamageToUI'

module Deepspace

# Brief: Representación ToUI de NumericDamage
class NumericDamageToUI < DamageToUI
  
  # new público
  public_class_method :new
  
  # Consultor del número de armas a eliminar
  attr_reader :nWeapons
  
  # Brief: Constructor con un parámetro
  # Param d: Instancia de la clase NumericDamage
  def initialize (d)
    super(d)
    @nWeapons=d.nWeapons
  end
    
  public
  
  # Brief: Devuelve la información del número de armas a eliminar
  # Return: String con la información del número de armas a eliminar
  def getWeaponInfo() 
    return @nWeapons.to_s
  end
  
end # Class

end # Module