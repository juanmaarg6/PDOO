#encoding:utf-8

# File: PowerEfficientSpaceStationToUI.rb
# Author: Profesor

require_relative 'SpaceStationToUI'

module Deepspace;

# Brief: Representación ToUI de PowerEfficientSpaceStation
class PowerEfficientSpaceStationToUI < SpaceStationToUI 

  # Brief: Constructor con un parámetro
  # Param efficientStation: Instancia de la clase PowerEfficientSpaceStation
  def initialize (efficientStation) 
    super(efficientStation)
  end
  
  # Brief: Consultor del nombre de la estación espacial eficiente
  # Return: out Nombre de la estación espacial eficiente
  def name
    out = super
    out += " (ESTACIÓN EFICIENTE)"
    return out
  end

end # Class

end # Module