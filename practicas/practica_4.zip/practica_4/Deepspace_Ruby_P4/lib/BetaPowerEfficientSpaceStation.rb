#encoding:utf-8

# File: BetaPowerEfficientSpaceStation.rb
# Author: Juan Manuel Rodríguez Gómez

require_relative 'Dice'
require_relative 'PowerEfficientSpaceStation'
require_relative 'BetaPowerEfficientSpaceStationToUI'

module Deepspace
    # Brief: Representa una estación espacial eficiente que utiliza una 
    #        tecnología en pruebas (beta) y que es potencialmente más eficiente
    #        al disparar
    #        Es una clase Hija de PowerEfficientSpaceStation
    class BetaPowerEfficientSpaceStation < PowerEfficientSpaceStation

        # Constante
        @@EXTRAEFFICIENCY=1.20
    
        # Brief: Constructor con un parámetro
        # Param station: Instancia de la clase SpaceStation
        def initialize(station)
            super
            @dice = Dice.new
        end
    
        # Brief: Realiza un disparo y se devuelve la energía o potencia del mismo. 
        #        Se determina aleatoriamente (usando un dado) si para ese disparo 
        #        la estación va a funcionar simplemente como una estación 
        #        eficiente normal o como una estación eficiente mejorada.
        # Return: La potencia del disparo
        def fire
            if @dice.extraEfficiency
                return super*@@EXTRAEFFICIENCY
            end
      
            return super
        end

        # Brief: Construye una nueva instancia BetaPowerEfficientSpaceStationToUI a partir de la propia 
        #        instancia que recibe el mensaje y lo devuelve.
        #        Estos objetos constituyen una capa que permite conectar el 
        #        modelo con la interfaz de usuario (BetaPowerEfficientSpaceStation) manteniendo 
        #        cierto nivel de aislamiento entre ambos niveles
        # Return: Instancia de la clase BetaPowerEfficientSpaceStationToUI
        def getUIversion
            return BetaPowerEfficientSpaceStationToUI.new(self)
        end
    
        # Brief: Función para representar una instancia de la clase 
        #        BetaPowerEfficientSpaceStation en un string
        # Return: String que representa una instancia de la clase 
        #           BetaPowerEfficientSpaceStation
        def to_s
            return "- Estacion espacial eficiente beta: \n" + super;
        end
    end # Class
end # Module