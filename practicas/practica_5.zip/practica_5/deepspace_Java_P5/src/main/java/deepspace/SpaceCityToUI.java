/**
 * @file SpaceCityToUI.java
 * @author Profesor
 */
package deepspace;

import java.util.ArrayList;

/**
 * @brief Representación ToUI de SpaceCity
 */
public class SpaceCityToUI extends SpaceStationToUI {

    // MIGUEL: He añadido este atributo para que el ToUI sea completo
    // Modificado el constructor y añadido un consultor
    ArrayList<SpaceStationToUI> collaborators = new ArrayList<>();
  
    /**
     * @brief Constructor con un parámetro
     * @param city Instancia de la clase SpaceCity
     */
    SpaceCityToUI (SpaceCity city) {
        super (city);
        for (SpaceStation s : city.getCollaborators()) {
            collaborators.add (new SpaceStationToUI(s));
        }
    }
  
    /**
     * @brief Consultor del nombre de la ciudad espacial
     * @return Nombre de la ciudad espacial
     */
    @Override
    public String getName () {
        return super.getName()+" (CIUDAD ESPACIAL)";
    }
  
    /**
     * @brief Consultor de los colaboradores de la ciudad espacial
     * @return collaborators
     */
    public ArrayList<SpaceStationToUI> getCollaborators() {
        return collaborators;
    }
}