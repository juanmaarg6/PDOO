/**
 * @file Damage.java
 * @author Juan Manuel Rodríguez Gómez
 */
package deepspace;

import java.util.ArrayList;

/**
 * @brief Representa el daño producido a una estación espacial por una nave 
 *        enemiga cuando se pierde un combate. Cada instancia indicará la 
 *        pérdida de una cantidad de potenciadores de escudo y por otro lado, 
 *        o bien una cantidad de tipos indeterminados de armas o un conjunto 
 *        de tipos de armas concretas que se deben eliminar
 */
public abstract class Damage {
    
    // Atributo de instancia
    public int nShields;
    
    /**
     * @brief Constructor con un parámetro
     * @param s Número de potenciadores de escudos a eliminar
     */
    Damage(int s) {
        nShields = s;
    }
    
    /**
     * @brief Constructor de copia
     * @param d Otra instancia de la clase Damage
     */
    Damage(Damage d) {
        nShields = d.nShields;
    }
    
    /**
     * @brief Devuelve una copia del objeto que reciba el mensaje
     * @return Copia del objeto que reciba el mensaje
     */
    abstract Damage copy();
    
    /**
     * @brief Construye una nueva instancia DamageToUI a partir de la propia 
     *        instancia que recibe el mensaje y lo devuelve.
     *        Estos objetos constituyen una capa que permite conectar el 
     *        modelo con la interfaz de usuario (Damage) manteniendo 
     *        cierto nivel de aislamiento entre ambos niveles
     * @return Instancia de la clase DamageToUI
     */
    abstract public DamageToUI getUIversion();
    
    /**
     * @brief Devuelve el índice de la posición de la primera arma de la 
     *        colección de armas (primer parámetro) cuyo tipo coincida con el 
     *        tipo indicado por el segundo parámetro. Devuelve -1 si no hay 
     *        ninguna arma en la colección del tipo indicado por el segundo 
     *        parámetro
     * @param w Colección de armas disponibles
     * @param t Tipo de arma a buscar
     * @return Índice de la posición de la primera arma de la colección de 
     *         armas cuyo tipo coincida con el tipo indicado por el segundo
     *         parámetro, o -1 si no se ha encontrado ninguna arma en la
     *         colección del tipo indicado por el segundo parámetro
     */
    int arrayContainsType(ArrayList<Weapon> w, WeaponType t) {
        
        int index = 0;
        
        for (Weapon weapon : w) {
            if(weapon.getType() == t)
                return index;
            else
                index++;
        }
        
        return -1;
    }
 
    /**
     * @brief Devuelve una versión ajustada del objeto a las colecciones de 
     *        armas y potenciadores de escudos suministradas como parámetro.
     *        Partiendo del daño representado por el objeto que recibe este 
     *        mensaje, se devuelve una copia del mismo pero reducida si es 
     *        necesario para que no implique perder armas o potenciadores de 
     *        escudos que no están en las colecciones de los parámetros
     * @param w Colección de armas disponibles
     * @param s Colección de potenciadores de escudo disponibles
     * @return Damage ajustado
     */
    abstract public Damage adjust(ArrayList<Weapon> w, ArrayList<ShieldBooster> s);
    
    /**
     * @brief Si la instancia dispone de una lista de tipos concretos de armas, 
     *        intenta eliminar el tipo del arma pasada como parámetro de esa 
     *        lista. En otro caso, simplemente decrementa en una unidad el 
     *        contador de armas que deben ser eliminadas. Ese contador no puede
     *        ser inferior a cero en ningún caso
     * @param w Arma cuyo tipo se va a eliminar de la lista de tipos concretos
     *          de armas disponibles, siempre que sea posible
     */
    abstract public void discardWeapon(Weapon w);
    
    /**
     * @brief Decrementa en una unidad el número de potenciadores de escudo que 
     *        deben ser eliminados. Ese contador no puede ser inferior a cero 
     *        en ningún caso
     */
    public void discardShieldBooster() {
        if(nShields > 0)
            nShields--;
    }
    
    /**
     * @brief Devuelve True si el daño representado no tiene ningún efecto.
     *        Esto quiere decir que no implica la pérdida de ningún tipo de 
     *        accesorio (armas o potenciadores de escudo)
     * @return True si el daño representado no tiene ningún efecto y 
     *         False en otro caso
     */
    abstract public boolean hasNoEffect();
    
    /**
     * @brief Consultor del número de potenciadores de escudo a eliminar
     * @return nShields
     */
    public int getNShields() {
        return nShields;
    }
    
    /**
     * @brief Función para representar una instancia de la clase Damage
     *        en un string
     * @return s String que representa una instancia de la clase Damage
     */
    @Override
    public String toString() {
        
        String s;
        
        s = "- Numero de potenciadores de escudo a eliminar: " + nShields + "\n";
        
        return s;
    }
}