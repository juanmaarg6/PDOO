/**
 * @file SafeHangarCardDeck.java
 * @author Profesor
 */
package deepspace;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

/**
 * @brief Mazo de cartas de objetos de Hangar
 */
class SafeHangarCardDeck extends CardDeck<Hangar> {
    
    /**
     * @brief Obtiene la siguiente carta del mazo de Hangar
     * @return Siguiente carta del mazo de Hangar
     */
    @Override
    public Hangar next() {
        Hangar h=(Hangar)(super.next());
        return new Hangar(h);
    }
}