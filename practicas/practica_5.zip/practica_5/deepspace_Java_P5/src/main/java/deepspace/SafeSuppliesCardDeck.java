/**
 * @file SafeSuppliesCardDeck.java
 * @author Profesor
 */
package deepspace;

/**
 * @brief Mazo de cartas de objetos de SuppliesPackage
 */
class SafeSuppliesCardDeck extends CardDeck<SuppliesPackage> {
    
    /**
     * @brief Obtiene la siguiente carta del mazo de SuppliesPackage
     * @return Siguiente carta del mazo de SuppliesPackage
     */
    @Override
    public SuppliesPackage next() {
        SuppliesPackage h=(SuppliesPackage)(super.next());
        return new SuppliesPackage(h);
    }
}