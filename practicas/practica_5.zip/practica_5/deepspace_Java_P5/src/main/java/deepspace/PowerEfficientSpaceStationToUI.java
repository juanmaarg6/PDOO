/**
 * @file PowerEfficientSpaceStationToUI.java
 * @author Profesor
 */
package deepspace;

/**
 * @brief Representación ToUI de PowerEfficientSpaceStation
 */
public class PowerEfficientSpaceStationToUI extends SpaceStationToUI {
  
    /**
    * @brief Constructor con un parámetro
    * @param efficientStation Instancia de la clase PowerEfficientSpaceStation
    */
    PowerEfficientSpaceStationToUI (PowerEfficientSpaceStation efficientStation) {
        super(efficientStation);
    }
  
    /**
    * @brief Consultor del nombre de la estación espacial eficiente
    * @return Nombre de la estación espacial eficiente
    */
    @Override
    public String getName () {
        return super.getName() + " (ESTACIÓN EFICIENTE)";
    }
}