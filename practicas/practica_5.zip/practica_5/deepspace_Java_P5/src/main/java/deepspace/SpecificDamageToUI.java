/**
 * @file SpecificDamageToUI.java
 * @author Profesor
 */
package deepspace;

import java.util.ArrayList;

/**
 * @brief Representación ToUI de SpecificDamage
 */
public class SpecificDamageToUI extends DamageToUI{
    private ArrayList<WeaponType> weapons;
    //    private int nShields;

    /**
     * @brief Constructor con un parámetro
     * @param d Instancia de la clase SpecificDamage
     */
    SpecificDamageToUI(SpecificDamage d) {
        super(d);
        ArrayList<WeaponType> tmp=d.getWeapons();
        if (tmp!=null) {
            weapons=new ArrayList<WeaponType>(tmp);
        }
    }

    /**
     * @brief Consultor del conjunto de armas concretas a eliminar
     * @return weapons
     */
    public ArrayList<WeaponType> getWeapons() {
        return weapons;
    }  
    
    /**
     * @brief Devuelve la información de la colección de armas concretas 
     *        a eliminar
     * @return String con la información de la colección de armas concretas 
     *         a eliminar
     */
    @Override
    public String getWeaponInfo() {
        String aux = weapons.toString();
        return aux.substring(1, aux.length()-1);
    }
}
