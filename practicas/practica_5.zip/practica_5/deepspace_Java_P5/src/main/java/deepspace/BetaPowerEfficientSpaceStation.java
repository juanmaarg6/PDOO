/**
 * @file BetaPowerEfficientSpaceStation.java
 * @author Juan Manuel Rodríguez Gómez
 */
package deepspace;

/**
 * @brief Representa una estación espacial eficiente que utiliza una 
 *        tecnología en pruebas (beta) y que es potencialmente más eficiente
 *        al disparar
 *        Es una clase Hija de PowerEfficientSpaceStation
 */
public class BetaPowerEfficientSpaceStation extends PowerEfficientSpaceStation {
    
    // Constante
    private final float EXTRAEFFICIENCY = 1.2f;
    
    // Atributo de relación
    private Dice dice = new Dice();
    
    /**
     * @brief Constructor con un parámetro
     * @param station Instancia de la clase SpaceStation
     */
    BetaPowerEfficientSpaceStation(SpaceStation station){
        super(station);
    }
    
    /**
     * @brief Realiza un disparo y se devuelve la energía o potencia del mismo. 
     *        Se determina aleatoriamente (usando un dado) si para ese disparo 
     *        la estación va a funcionar simplemente como una estación 
     *        eficiente normal o como una estación eficiente mejorada.
     * @return La potencia del disparo
     */
    @Override
    public float fire() {
        if( dice.extraEfficiency() )
            return super.fire()*EXTRAEFFICIENCY;
        
        return super.fire();
    }
    
    /**
     * @brief Construye una nueva instancia BetaPowerEfficientSpaceStationToUI 
     *        a partir de la propia instancia que recibe el mensaje y 
     *        lo devuelve.
     *        Estos objetos constituyen una capa que permite conectar el 
     *        modelo con la interfaz de usuario (BetaPowerEfficientSpaceStation)
     *        manteniendo cierto nivel de aislamiento entre ambos niveles
     * @return Instancia de la clase BetaPowerEfficientSpaceStationToUI
     */
    @Override
    public BetaPowerEfficientSpaceStationToUI getUIversion() {
        return new BetaPowerEfficientSpaceStationToUI(this);
    }
    
    /**
     * @brief Función para representar una instancia de la clase 
     *        BetaPowerEfficientSpaceStation en un string
     * @return s String que representa una instancia de la clase 
     *           BetaPowerEfficientSpaceStation
     */
    @Override
    public String toString() {
        return "- Estacion espacial eficiente beta: \n" + super.toString();
    }
}