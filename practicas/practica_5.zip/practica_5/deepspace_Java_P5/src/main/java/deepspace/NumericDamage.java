/**
 * @file NumericDamage.java
 * @author Juan Manuel Rodríguez Gómez
 */
package deepspace;

import java.util.ArrayList;

/**
 * @brief Representa el daño producido a una estación espacial por una nave 
 *        enemiga cuando se pierde un combate. Cada instancia indicará la 
 *        pérdida de una cantidad de potenciadores de escudo y una cantidad
 *        de armas.
 *        Es una clase Hija de Damage.
 *        Además de heredar el atributo de potenciadores de escudo a perder, 
 *        se implementa la cantidad de armas a perder con un contador
 */
public class NumericDamage extends Damage {
    
    // Atributo de instancia
    private int nWeapons;
    
    /**
     * @brief Constructor con parámetros
     * @param w Número de armas a eliminar
     * @param s Número de potenciadores de escudos a eliminar
     */
    NumericDamage(int w, int s) {
        super(s);
        nWeapons = w;
    }
    
    /**
     * @brief Constructor de copia
     * @param nd Otra instancia de la clase NumericDamage
     */
    NumericDamage(NumericDamage nd) {
        super(nd);
        nWeapons = nd.nWeapons;
    }
    
    /**
     * @brief Consultor del número de armas a eliminar
     * @return nWeapons
     */
    public int getNWeapons() {
        return nWeapons;
    }
    
    /**
     * @brief Devuelve una copia del objeto NumericDamage
     * @return Copia del objeto NumericDamage
     */
    @Override
    NumericDamage copy() {
        return new NumericDamage(nWeapons, nShields);
    }
    
    /**
     * @brief Construye una nueva instancia NumericDamageToUI a partir de la 
     *        propia instancia que recibe el mensaje y lo devuelve.
     *        Estos objetos constituyen una capa que permite conectar el 
     *        modelo con la interfaz de usuario (NumericDamage) manteniendo 
     *        cierto nivel de aislamiento entre ambos niveles
     * @return Instancia de la clase NumericDamageToUI
     */
    @Override
    public NumericDamageToUI getUIversion() {
        return new NumericDamageToUI(this);
    }
    
    /**
     * @brief Devuelve una versión ajustada del objeto a las colecciones de 
     *        armas y potenciadores de escudos suministradas como parámetro.
     *        Partiendo del daño representado por el objeto que recibe este 
     *        mensaje, se devuelve una copia del mismo pero reducida si es 
     *        necesario para que no implique perder armas o potenciadores de 
     *        escudos que no están en las colecciones de los parámetros
     * @param w Colección de armas disponibles
     * @param s Colección de potenciadores de escudo disponibles
     * @return NumericDamage ajustado
     */
    @Override
    public NumericDamage adjust(ArrayList<Weapon> w, ArrayList<ShieldBooster> s) {

        // Mínimo entre el número de potenciadores de escudo disponibles y el 
        // número de potenciadores de escudo a eliminar
        int minNShields = Math.min( nShields, s.size() );
        
        // Mínimo entre el número de armas disponibles y el número de armas
        // a eliminar
        int minNWeapons = Math.min( nWeapons, w.size() );
        
        // Devolvemos el NumericDamage ajustado con el número de potenciadores 
        // de escudo y el número de armas a eliminar
        return new NumericDamage(minNWeapons, minNShields);
    }
    
    /**
     * @brief Decrementa en una unidad el contador de armas que deben ser 
     *        eliminadas. Ese contador no puede ser inferior a cero en ningún 
     *        caso
     * @param w Arma cuyo tipo se va a eliminar de la lista de tipos concretos
     *          de armas disponibles, siempre que sea posible
     */
    @Override
    public void discardWeapon(Weapon w) {
        if(nWeapons > 0)
            nWeapons--;
    }
    
    /**
     * @brief Devuelve True si el daño representado no tiene ningún efecto.
     *        Esto quiere decir que no implica la pérdida de ningún tipo de 
     *        accesorio (armas o potenciadores de escudo)
     * @return True si el daño representado no tiene ningún efecto y 
     *         False en otro caso
     */
    @Override
    public boolean hasNoEffect() {
        return ((nShields == 0) && (nWeapons == 0));
    }

    /**
     * @brief Función para representar una instancia de la clase Damage
     *        en un string
     * @return s String que representa una instancia de la clase Damage
     */
    @Override
    public String toString() {
        
        String s;
        
        String s_nShields = "- Numero de potenciadores de escudo a eliminar: " + nShields + "\n";
        String s_nWeapons = "- Numero de armas a eliminar: " + nWeapons + "\n";

        s = s_nShields + s_nWeapons;
        
        return s;
    }
}