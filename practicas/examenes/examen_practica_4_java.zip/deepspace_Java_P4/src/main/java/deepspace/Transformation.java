/**
 * @file Transformation.java
 * @author Juan Manuel Rodríguez Gómez
 */
package deepspace;

/**
 * @brief Representa las posibles transformaciones que puede sufrir una 
 *        estación espacial
 */
public enum Transformation {
    NOTRANSFORM, GETEFFICIENT, SPACECITY;
}
