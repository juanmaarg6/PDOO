/**
 * @file PowerEfficientSpaceStation.java
 * @author Juan Manuel Rodríguez Gómez
 */
package deepspace;

/**
 * @brief Representa una estación espacial eficiente. Este tipo de estaciones
 *        espaciales consiguen que se incremente la potencia de disparo y de
 *        protección en un determinado factor constante respecto a las 
 *        estaciones estándar. Estas no pueden transformarse en ciudades
 *        espaciales
 *        Es una clase Hija de SpaceStation
 */
public class PowerEfficientSpaceStation extends SpaceStation {
    
    // Constante
    private final float EFFICIENCYFACTOR = 1.10f;
    
    /**
     * @brief Constructor con un parámetro
     * @param station Instancia de la clase SpaceStation
     */
    PowerEfficientSpaceStation(SpaceStation station) {
        super(station);
    }
    
    /**
     * @brief Realiza un disparo y se devuelve la energía o potencia del mismo. 
     *        La potencia de dicho disparo se ve incrementada por un
     *        factor constante
     * @return La potencia del disparo incrementada
     */
    @Override
    public float fire() {
        return super.fire()*EFFICIENCYFACTOR;
    }
    
    /**
     * @brief Se usa el escudo de protección y se devuelve la energía del mismo. 
     *        La energia de dicho escudo de protección se ve incrementada por 
     *        un factor constante
     * @return La energía del escudo de protección incrementada
     */
    @Override
    public float protection() {
        return super.protection()*EFFICIENCYFACTOR;
    }

    /**
     * @brief Recepción de un botín
     * @param loot Botín a recibir
     * @return Transformación de la estación espacial
     */
    @Override
    public Transformation setLoot(Loot loot) {
        super.setLoot(loot);
        
        if( loot.getEfficient() )
            return Transformation.GETEFFICIENT;
        else
            return Transformation.NOTRANSFORM;
    }
    
    /**
     * @brief Construye una nueva instancia PowerEfficientSpaceStationToUI a 
     *        partir de la propia instancia que recibe el mensaje y lo devuelve.
     *        Estos objetos constituyen una capa que permite conectar el 
     *        modelo con la interfaz de usuario (PowerEfficientSpaceStation) 
     *        manteniendo cierto nivel de aislamiento entre ambos niveles
     * @return Instancia de la clase PowerEfficientSpaceStationToUI
     */
    @Override
    public PowerEfficientSpaceStationToUI getUIversion() {
        return new PowerEfficientSpaceStationToUI(this);
    }
    
    /**
     * @brief Función para representar una instancia de la clase 
     *        PowerEfficientSpaceStation en un string
     * @return s String que representa una instancia de la clase 
     *           PowerEfficientSpaceStation
     */
    @Override
    public String toString() {
        return "- Estacion espacial eficiente: \n" + super.toString();
    }
}