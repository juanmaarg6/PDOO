/**
 * @file ExamenP4.java
 * @author Juan Manuel Rodríguez Gómez
 */
package deepspace;

import java.util.ArrayList;

public class ExamenP4 {
    
    public static final int NSTATIONS = 20;
    public static final int INDEX_SECOND_STATION = 1;

    public static void main(String[] args) {
        
        
        CardDealer dealer = CardDealer.getInstance();

        ArrayList<SpaceStation> spaceStations = new ArrayList<>();
        
        for(int i = 0; i < NSTATIONS; i++)
            spaceStations.add( new SpaceStation( "Estacion espacial", dealer.nextSuppliesPackage() ) );
        
        System.out.println("Proteccion ANTES de transformar la segunda estacion espacial en ciudad espacial: ");
        for(int i = 0; i < spaceStations.size(); i++)
            System.out.println( spaceStations.get(i).protection() );  
        
        ArrayList<SpaceStation> collaborators = new ArrayList<>(spaceStations);
        collaborators.remove(INDEX_SECOND_STATION);
        spaceStations.remove(INDEX_SECOND_STATION);
        spaceStations.add(INDEX_SECOND_STATION, new SpaceCity( spaceStations.get(INDEX_SECOND_STATION), collaborators) );
        
        System.out.println("Proteccion DESPUES de transformar la segunda estacion espacial en ciudad espacial: ");
        for(int i = 0; i < spaceStations.size(); i++)
            System.out.println( spaceStations.get(i).protection() );
        
        System.out.println("Usos de 2 armas y 2 potenciadores de escudo en un ArrayList: ");
        ArrayList<CombatElement> WeaponsAndShields = new ArrayList<>();
        
        WeaponsAndShields.add( dealer.nextWeapon() );
        WeaponsAndShields.add( dealer.nextWeapon() );
        WeaponsAndShields.add( dealer.nextShieldBooster() );
        WeaponsAndShields.add( dealer.nextShieldBooster() );

        for(int i = 0; i < WeaponsAndShields.size(); i++)
            System.out.println( WeaponsAndShields.get(i).getUses() );
    } 
}