/**
 * @file CombatElement.java
 * @author Juan Manuel Rodríguez Gómez
 */
package deepspace;

/**
 * @brief Interfaz de juego utilizada para Weapon y ShieldBooster
 */
public interface CombatElement {
    public int getUses();
    public float useIt();
}