/**
 * @file SpaceCity.java
 * @author Juan Manuel Rodríguez Gómez
 */
package deepspace;

import java.util.ArrayList;

/**
 * @brief Representa la transformación de estaciones espaciales en 
 *        ciudades espaciales. 
 *        Las ciudades espaciales están formadas por la estación que tenía el 
 *        jugador y las estaciones espaciales del resto de jugadores. 
 *        Son a su vez un tipo de estación espacial
 */
public class SpaceCity extends SpaceStation {
    
    // Atributos de relación
    private SpaceStation base;
    private ArrayList<SpaceStation> collaborators;
    
    /**
     * @brief Constructor con parámetros
     * @param b Estación espacial base de la ciudad
     * @param rest Colaboradores de la ciudad espacial
     */
    SpaceCity(SpaceStation b, ArrayList<SpaceStation> rest) {
        super(b);
        base = b;
        collaborators = new ArrayList<>(rest);
    }
    
    /**
     * @brief Consultor de los colaboradores de la ciudad espacial
     * @return collaborators
     */
    public ArrayList<SpaceStation> getCollaborators() {
        return collaborators;
    }
    
    /**
     * @brief Realiza un disparo entre todas las estaciones que forman la
     *        ciudad espacial y se devuelve la energía o potencia del mismo
     * @return La potencia del disparo
     */
    @Override
    public float fire() {
        float factor = base.fire();
        for(int i = 0; i < collaborators.size(); i++)
            factor += collaborators.get(i).fire();
        
        return factor;
    }
    
    /**
     * @brief Se usa el escudo de protección de todas las estaciones que 
     *        forman la ciudad espacial y se devuelve la energía del mismo
     * @return La energía del escudo de protección
     */
    @Override
    public float protection() {
        float factor = base.protection();
        for(int i = 0; i < collaborators.size(); i++)
            factor += collaborators.get(i).protection();
        
        return factor;
    }
    
    /**
     * @brief Recepción de un botín para la base de la ciudad espacial
     * @param loot Botín a recibir
     * @return La ciudad espacial no puede volver a transformarse
     */
    @Override
    public Transformation setLoot(Loot loot) {
        base.setLoot(loot);
        return Transformation.NOTRANSFORM;
    }
    
    /**
     * @brief Construye una nueva instancia SpaceCityToUI a partir de la propia 
     *        instancia que recibe el mensaje y lo devuelve.
     *        Estos objetos constituyen una capa que permite conectar el 
     *        modelo con la interfaz de usuario (SpaceCity) manteniendo 
     *        cierto nivel de aislamiento entre ambos niveles
     * @return Instancia de la clase SpaceCityToUI
     */
    @Override
    public SpaceCityToUI getUIversion() {
        return new SpaceCityToUI(this);
    }
    
    /**
     * @brief Función para representar una instancia de la clase SpaceCity
     *        en un string
     * @return s String que representa una instancia de la clase SpaceCity
     */
    @Override
    public String toString() {
        
        String s;
        
        String s_base = "- Estacion Espacial Base de la Ciudad Espacial: " + base.toString() + "\n";
        
        String s_collaborators = "- Colaboradores de la Ciudad Espacial: " + collaborators.get(0).toString() + "\n";        
        for(int i = 1; i < collaborators.size(); i++)
            s_collaborators += collaborators.get(i).toString();
        
        s = s_base + s_collaborators;
                
        return s;
    }
}