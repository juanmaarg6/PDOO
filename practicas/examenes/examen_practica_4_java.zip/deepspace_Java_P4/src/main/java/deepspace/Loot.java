/**
 * @file Loot.java
 * @author Juan Manuel Rodríguez Gómez
 */
package deepspace;

/**
 * @brief Representa el botín que se obtiene al vencer a una nave enemiga. 
 *        Puede incluir cantidades que representen un número de paquetes de 
 *        suministros, armas, potenciadores de escudo, hangares y/o medallas.
 */
class Loot {
    
    // Atributos de instancia
    private int nSupplies;
    private int nWeapons;
    private int nShields;
    private int nHangars;
    private int nMedals;
    private boolean getEfficient;
    private boolean spaceCity;

    /**
     * @brief Constructor con parámetros
     * @param nsu Número de suministros
     * @param nw Número de armas
     * @param nsh Número de escudos
     * @param nh Número de hangares
     * @param nm Número de medallas
     */
    Loot(int nsu, int nw, int nsh, int nh, int nm) {
        nSupplies = nsu;
        nWeapons = nw;
        nShields = nsh;
        nHangars = nh;
        nMedals = nm;
        getEfficient = false;
        spaceCity = false;
    }
    
    /**
     * @brief Constructor con parámetros
     * @param nsu Número de suministros
     * @param nw Número de armas
     * @param nsh Número de escudos
     * @param nh Número de hangares
     * @param nm Número de medallas
     * @param ef Estación espacial se convertirá o no en eficiente
     * @param city Se creará o no una ciudad espacial
     */
    Loot(int nsu, int nw, int nsh, int nh, int nm, boolean ef, boolean city){
        nSupplies = nsu;
        nWeapons = nw;
        nShields = nsh;
        nHangars = nh;
        nMedals = nm;
        getEfficient = ef;
        spaceCity = city;
    }
    /**
     * @brief Consultor del número de suministros
     * @return nSupplies
     */
    public final int getNSupplies() {
        return nSupplies;
    }
    
    /**
     * @brief Consultor del número de armas
     * @return nWeapons
     */
    public final int getNWeapons() {
        return nWeapons;
    }
    
    /**
     * @brief Consultor del número de escudos
     * @return nShields
     */
    public final int getNShields() {
        return nShields;
    }
    
    /**
     * @brief Consultor del número de hangares
     * @return nHangars
     */
    public final int getNHangars() {
        return nHangars;
    }
    
    /**
     * @brief Consultor del número de medallas
     * @return nMedals
     */
    public final int getNMedals() {
        return nMedals;
    }
    
    /**
     * @brief Consultor de si una estación espacial pasará a ser eficiente o no
     * @return getEfficient
     */
    public boolean getEfficient(){
        return getEfficient;
    }
    
    /**
     * @brief Consultor de si se creará o no una ciudad espacial
     * @return spaceCity
     */
    public boolean spaceCity(){
        return spaceCity;
    }
    
    /**
     * @brief Construye una nueva instancia LootToUI a partir de la propia 
     *        instancia que recibe el mensaje y lo devuelve.
     *        Estos objetos constituyen una capa que permite conectar el 
     *        modelo con la interfaz de usuario (Loot) manteniendo cierto nivel 
     *        de aislamiento entre ambos niveles
     * @return Instancia de la clase LootToUI
     */
    public LootToUI getUIversion() {
        return new LootToUI(this);
    }
    
    /**
     * @brief Función para representar una instancia de la clase Loot 
     *        en un string
     * @return s String que representa una instancia de la clase Loot
     */
    public String toString() {
        
        String s;
        
        String s_nSupplies = "- Numero de suministros: " + nSupplies + "\n";
        String s_nWeapons = "- Numero de armas: " + nWeapons + "\n";
        String s_nShields = "- Numero de escudos: " + nShields + "\n";
        String s_nHangars = "- Numero de hangares: " + nHangars + "\n";
        String s_nMedals = "- Numero de medallas: " + nMedals + "\n";
        
        s = s_nSupplies + s_nWeapons + s_nShields + s_nHangars + s_nMedals;
        
        return s;
    }
}