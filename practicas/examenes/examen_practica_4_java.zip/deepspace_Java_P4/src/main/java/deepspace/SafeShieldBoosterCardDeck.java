/**
 * @file SafeShieldBoosterCardDeck.java
 * @author Profesor
 */
package deepspace;

/**
 * @brief Mazo de cartas de objetos de ShieldBooster
 */
class SafeShieldBoosterCardDeck extends CardDeck<ShieldBooster> {
    
    /**
     * @brief Obtiene la siguiente carta del mazo de ShieldBooster
     * @return Siguiente carta del mazo de ShieldBooster
     */
    @Override
    public ShieldBooster next() {
        ShieldBooster h=(ShieldBooster)(super.next());
        return new ShieldBooster(h);
    }
}