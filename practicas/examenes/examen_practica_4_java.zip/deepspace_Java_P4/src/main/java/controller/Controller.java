/**
 * @file Controller.java
 * @author Profesor
 */
package controller;

import View.DeepSpaceView;
import deepspace.CombatResult;
import deepspace.GameState;
import deepspace.GameUniverse;
import deepspace.GameUniverseToUI;
import java.util.ArrayList;
import java.util.Collections;

/**
 * @brief Esta clase de carácter Singleton representa un controlador que permite 
 *        conectar la interfaz visible para el usuario (ya sea gráfica o de 
 *        texto) con el modelo (en este caso GameUniverse).
 * 
 *        Para ello se disponen una serie de métodos que permiten controlar  
 *        las diferentes funcionalidades básicas del juego
 */
public class Controller {
    private static final Controller instance = new Controller();
    
    public static final int WEAPON = 0x1;
    public static final int SHIELD = 0x2;
    public static final int HANGAR = 0x4;
    private GameUniverse game;
    private DeepSpaceView view;
    
    /**
     * @brief Constructor por defecto
     */
    private Controller () {}
    
    /**
     * @brief Devuelve una instancia Singleton de Controller
     * @return Instancia de Controller (Singleton)
     */
    public static Controller getInstance () {
      return instance;
    }
    
    /**
     * @brief Asocia una instancia de Juego y una instancia de Vista al 
     *        controlador
     * @param aGame Instancia de la clase GameUniverse
     * @param aView Instancia de la clase DeepSpaceView
     */
    public void setModelView (GameUniverse aGame, DeepSpaceView aView) {
      game = aGame;
      view = aView;
    }
    
    /**
     * @brief Inicia una nueva partida
     */
    public void start() {
        game.init(view.readNamePlayers());
        view.updateView();
        view.showView();
    }
    
    /**
     * @brief Finaliza la partida y detiene la ejecución del programa
     * @param i Flag de salida con estado final de ejecución (normalmente 0)
     */
    public void finish (int i) {
        if (view.confirmExitMessage()) {
          System.exit(i);
        }
    }
    
    /**
     * @brief Comprueba si se puede pasar de turno
     * @return True (1) si se puede pasar de turno y False (0) si no se puede
     */
    public boolean nextTurn () {
      boolean nextTurnAllowed = game.nextTurn();
      if (!nextTurnAllowed) {
        view.nextTurnNotAllowedMessage();
      }
      return nextTurnAllowed;
    }
    
    /**
     * @brief Combate entre una estación espacial y un enemigo
     */
    public void combat () {
        CombatResult result = game.combat();
        switch (result) {
            case ENEMYWINS :
              view.lostCombatMessage();
              break;
            case STATIONESCAPES :
              view.escapeMessage();
              break;
            case STATIONWINS :
              view.wonCombatMessage();
              if (game.haveAWinner()) {
                  view.wonGameMessage();
                  System.exit (0);
              }
              break;
            case STATIONWINSANDCONVERTS :
              view.conversionMessage();
              break;
            case NOCOMBAT :
              view.noCombatMessage();
              break;
        }
    }
    
    /**
     * @brief Consultor del estado actual del juego
     * @return state
     */
    public GameState getState() {
      return game.getState();
    }
    
    /**
     * @brief Construye una nueva instancia GameUniverseToUI a partir de la 
     *        propia instancia que recibe el mensaje y lo devuelve.
     *        Estos objetos constituyen una capa que permite conectar el 
     *        modelo con la interfaz de usuario (GameUniverse) manteniendo 
     *        cierto nivel de aislamiento entre ambos niveles
     * @return Instancia de la clase GameUniverseToUI
     */
    public GameUniverseToUI getUIversion() {
      return game.getUIversion();
    }
    
    /**
     * @brief Invierte un array de números enteros
     * @param array Array de números enteros a invertir
     */
    private void invertArray (ArrayList<Integer> array) {
      int i, n;
      
      n = array.size();
      for (i = 0; i < n/2; i++)
        Collections.swap(array, i, n-i-1);
    }
    
    /**
     * @brief Monta los objetos que se pasan como parámetros
     * @param weapons Array de índices de las armas a montar
     * @param shields Array de índices de los potenciadores de escudo a montar
     */
    public void mount (ArrayList<Integer> weapons, ArrayList<Integer> shields) {
      invertArray (weapons);
      invertArray (shields);
      
      for (int i : weapons) {
        game.mountWeapon(i);
      }
      for (int i : shields) {
        game.mountShieldBooster(i);
      }
    }
    
    /**
     * @brief Descarta los objetos pasados como parámetros
     * @param places Flag que permite indicar de dónde se descartan 
     *               (WEAPON | SHIELD | HANGAR)
     * @param weapons Array de índices de las armas a descartar
     * @param shields Array de índices de los potenciadores de escudo a 
     *                descartar
     */
    public void discard (int places, ArrayList<Integer> weapons, ArrayList<Integer> shields) {
      invertArray(weapons);
      invertArray(shields);
      
      if ((places & WEAPON) == WEAPON) {
        for (int i : weapons) {
          game.discardWeapon(i);
        }
      } else if ((places & SHIELD) == SHIELD) {
        for (int i : shields) {
          game.discardShieldBooster(i);
        }
      } else if((places & HANGAR) == HANGAR) {
        for (int i : weapons) {
          game.discardWeaponInHangar(i);
        }
        for (int i : shields) {
          game.discardShieldBoosterInHangar(i);
        }
      }
    }
    
    /**
     * @brief Descarta el hangar del jugador actual
     */
    public void discardHangar () {
        game.discardHangar();
    }
}
