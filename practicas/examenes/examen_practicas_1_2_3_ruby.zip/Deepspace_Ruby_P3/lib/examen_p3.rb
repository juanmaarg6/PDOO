#encoding:utf-8

# File: examen_p3.rb
# Author: Juan Manuel Rodríguez Gómez

require_relative 'Damage'
require_relative 'WeaponType'

module P3

    class ExamenP3

        def principal

            # Damage
            type1 = Deepspace::WeaponType::LASER
            type2 = Deepspace::WeaponType::MISSILE
            type3 = Deepspace::WeaponType::PLASMA
            type4 = Deepspace::WeaponType::ONEPUNCH

            arrayTypes = [type1, type1, type2, type2, type3, type3, type4, type4]
            damage = Deepspace::Damage.newSpecificWeapons(arrayTypes, 0)
        
            puts "Damage: \n#{damage.to_s}\n"

            # Estación espacial
            weapon1 = Deepspace::Weapon.new("W1", Deepspace::WeaponType::LASER, 1)
            weapon2 = Deepspace::Weapon.new("W2", Deepspace::WeaponType::PLASMA, 2)
            weapon3 = Deepspace::Weapon.new("W3", Deepspace::WeaponType::PLASMA, 3)
            weapon4 = Deepspace::Weapon.new("W4", Deepspace::WeaponType::PLASMA, 4)
            weapon5 = Deepspace::Weapon.new("W5", Deepspace::WeaponType::ONEPUNCH, 5)
            weapon6 = Deepspace::Weapon.new("W6", Deepspace::WeaponType::ONEPUNCH, 6)

            station_arrayWeapons = [weapon1, weapon2, weapon3, weapon4, weapon5, weapon6]
            
            # Damage ajustado a la estación espacial 
            adjustDamage = damage.adjust(station_arrayWeapons, [])
            
            puts "Damage ajustado a la Estacion Espacial: \n#{adjustDamage.to_s}\n"
        
            # Prueba del nuevo constructor de Damage
            damageNewConstructor = Deepspace::Damage.newConstructor()
        
            puts "Damage usando el nuevo constructor: \n#{damageNewConstructor.to_s}\n" 
        end
    end # Class
end # Module

examen= P3::ExamenP3.new
examen.principal